import java.util.Scanner;
public class prc {
     static Scanner sn=new Scanner(System.in);
    public static void main(String[] args) {
        // int a=sn.nextInt();
        // int b=sn.nextInt();
        // int max_num=Math.max(a,b);
        // System.out.println(max_num);
        System.out.println("Ej");
    }
}
