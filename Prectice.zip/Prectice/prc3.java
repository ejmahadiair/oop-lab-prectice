public class prc3 {
    public static void main(String[] args) {
        String st="This is an String";
        String strev="";
        char ch;
        for(int i=st.length()-1;i>=0;i--) {
            ch = st.charAt(i);
            strev=strev+ch;
        }
        System.out.print(strev);
    }
}
