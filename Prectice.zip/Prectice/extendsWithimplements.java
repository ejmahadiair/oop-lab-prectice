//We can extends of implements both of class and interface
class myClass{
    public void printmyClass(){
        System.out.println("This is myClass");
    }
}
interface yourClass{
abstract void printyourClass();
}
// Remember whenever we extends with implements we have to extends first
public class extendsWithimplements extends myClass implements yourClass{
    public void printyourClass(){
        System.out.println("This is yourClass");
    }
    public static void main(String[] args) {
        extendsWithimplements ext=new extendsWithimplements();
        ext.printmyClass();
        ext.printyourClass();
    }
}
