import java.util.Scanner;
public class test {
    static Scanner sc=new Scanner(System.in);
    public static void main(String[] args) {
        
    //     System.out.println("Enter your name : ");
    //     int a=sc.nextInt();
    //     float f=sc.nextFloat();
    //     double d=sc.nextDouble();
    //    String s=sc.nextLine();
    //     boolean tf=sc.nextBoolean();
    //    System.out.println("The name is: "+s);
    // System.out.println("Enter num1 : ");
    // int a=sc.nextInt();
    // System.out.println("Enter num 2 : ");
    // int b=sc.nextInt();
    // int sum=a+b;
    // System.out.println("The sum is : "+sum);
    // System.out.print("The sentence in \n next line");
    // System.out.printf("The sum is : %d, %d,%.02f",sum,b);


    }
}
