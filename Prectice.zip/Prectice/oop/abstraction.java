package oop;

//Bellow an abstract class. when ever we want to creat a abstract class we must be use the abstract keyword first of the class.
abstract class eastern{
    //bellow a general method in abstract class we can build abstruct and general both method.
    public void coffe(){
        System.out.println("The Coffe is here");
    }
    //This is a abstract method. In abstract method have no body.
    abstract public void tea();
}
//If we want to get data from abstract class we have to extends in an child class then we have to call the chilt class in main class.
class cantin extends eastern{
    //here we have to build the full method of abstract class.
public void tea(){
        System.out.println("Here the Tea");
    }
}

//here called the child class 
public class abstraction extends cantin{
    public static void main(String[] args) {
        //Finally we can get access in every item of abstract class
        cantin order=new cantin();
        order.tea();
        order.coffe();
    }
}