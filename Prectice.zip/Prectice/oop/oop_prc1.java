package oop;
// class sakib{
//     public void saka(){
//         System.out.println("Mr. Sakib");
//     }
// }
 class jummon{
    String st;
     public jummon(String st){
        this.st = st;
    }
    public void something(){
        System.out.println("Mr.Jummon, "+st);
    }
}
class Student{
    int id;
    String name;
    int age;
     Student(int ids,String names){
        id = ids;
        name = names;
    }
     Student(int ids,String names,int ages){
        id = ids;
        name = names;
        age = ages;
    }
    Student (){
        System.out.println("Unknow");
    }
    public void printf(){
        System.out.println(id+" "+name+" "+age);
    }
}
public class oop_prc1 extends jummon {
    public oop_prc1(String st) {
        super(st);
    }

    public static void main(String[] args) {
        // jummon jem=new jummon("Fairuz");
        // jem.something();

        Student st1=new Student(11,"Fairuz");
        Student st2=new Student(12,"Sakib",30);
        Student st3=new Student(23,"djhj");
        Student st4=new Student();
        st3.printf();
         System.out.println(st1.id+" "+st1.name);
        st2.printf();
        

    }
}
