import java.util.Arrays;
public class prc2 {
    public static void main(String[] args) {
        int [] arr={5,6,3,4,8,1,7,9};  
        Arrays.sort(arr);
        System.out.println(arr);
        for(int i=0; i<arr.length; i++) {
            System.out.print(arr[i]+" ");
        }
        System.out.println();
        int large3rd=arr[5];
        System.out.println(large3rd);
    }
}
