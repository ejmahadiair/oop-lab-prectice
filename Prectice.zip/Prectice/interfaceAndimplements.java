//Interface is an 100% abstract so if we want to creat an method in interface then we have to declare abstract before the public void.
interface dog{
    abstract public void dogdo();
}
interface cat{
abstract public void catdo();
}
interface animel{
abstract public void animeldo();
}

// for call the interface we need to use the keyword implements. The main feture is we can implements a bunch of interface
public class interfaceAndimplements implements dog, cat, animel{
    public void dogdo(){
        System.out.println("Dog can eat");
    }
    public void catdo(){
        System.out.println("Cat can eat");
    }
    public void animeldo(){
        System.out.println("Dog and cat both animel can eat");
    }
    public static void main(String[] args) {
        interfaceAndimplements job=new interfaceAndimplements();
        job.dogdo();
        job.catdo();
        job.animeldo();
    }
}
