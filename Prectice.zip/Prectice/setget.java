
class student{
    private String name;
    private int id;
    public void setinfo(String name,int id){
        this.name = name;
        this.id = id;
    }
    public void getinfo(){
        System.out.println(this.name+"\n id is : "+this.id);
    }
}

public class setget extends student {
    public static void main(String[] args) {
        student st1 = new student();
        st1.setinfo("Name is: Student", 101);
        st1.getinfo();
    }
}
