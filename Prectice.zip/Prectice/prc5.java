import java.util.Scanner;
public class prc5 {
    static Scanner sn=new Scanner(System.in);
    public static void main(String[] args) {
       int a=sn.nextInt();
        int b=sn.nextInt();
        int c=sn.nextInt();
        if(a>b && a>c){
            System.out.println(a);
        }else if(b>a && b>c){
            System.out.println(b);
        }else{
            System.out.println(c);
        }
        
    // System.out.println("Ej");
    }
}
