public class prc1{
    public static void main(String[] args) {
        int[] mainarr={1,2,3,4,5,6,7,8,9};
        int n=mainarr.length;
        int j=n;
        int [] newArray=new int[n];
        
        // for(int i=0;i<n;i++){
            
        //     newArray[j-1]=mainarr[i];
        //     j--;
        // }
        // System.out.println(newArray);
        // for(int i=0;i<n;i++){
        //     System.out.print(newArray[i]+" ");
        // }
        // for(int i=n-1;i>=0;i--){
        //     System.out.print(mainarr[i]+" ");
        // }
        
        
    }
}