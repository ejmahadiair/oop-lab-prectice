public class prc4 {
    public static void main(String[] args) {
        String sentence="I love Bangladesh";
        String [] stntence2=sentence.split(" ");
        String revSentence="";
        for(int i=stntence2.length-1; i>=0; i--) {
            revSentence=revSentence+ stntence2[i]+" ";
        }
        System.out.print(revSentence+" ");
    }
}
 